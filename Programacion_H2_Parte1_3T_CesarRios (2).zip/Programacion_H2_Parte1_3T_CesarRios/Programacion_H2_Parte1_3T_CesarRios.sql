DROP DATABASE IF EXISTS cine;
CREATE DATABASE cine;
USE cine;

CREATE TABLE Generos (
    id_genero INT PRIMARY KEY,
    nombre_genero VARCHAR(50)
);
CREATE TABLE Peliculas (
    id_pelicula VARCHAR(10) PRIMARY KEY,
    titulo VARCHAR(100),
    director VARCHAR(100),
    duracion INT,
    clasificacion VARCHAR(10),
    genero_id INT,
    FOREIGN KEY (genero_id) REFERENCES Generos(id_genero)
);


INSERT INTO Generos VALUES (1, 'Acción'), (2, 'Comedia'), (3, 'Drama');

INSERT INTO Peliculas VALUES 
('P001', 'Star Wars', 'George Lucas', 122, 'R', 1),
('P002', 'Toy Story', 'John Lasseter', 80, 'G', 2),
('P003', 'Salvar al soldado Ryan', 'Robert Rodat', 175, 'R', 3),
('P004', 'fast and Furious', 'Gary Scott', 120, 'R', 1),
('P005', 'Ángeles y demonios', 'Dan Brown', 125, 'R', 3);

<?php
session_start();
require_once '../config/conexion.php';

//verificamos que el usuario está autenticado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: iniciar_sesion.php");
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
//obtenemos el ID de la tarea de la URL
$tarea_id = $_GET['id']; 

$conexion = new Conexion();
$conexion = $conexion->getConexion();

//obtenemos los datos de la tarea que el usuario va a editar
$query = "SELECT id, titulo, descripcion, estado FROM tareas WHERE id = ? AND usuario_id = ?";
$stmt = $conexion->prepare($query);
$stmt->bind_param("ii", $tarea_id, $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$tarea = $result->fetch_assoc(); 
$stmt->close();

//se actualiza la tarea mediante el post
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nuevo_titulo = $_POST['titulo'];
    $nueva_descripcion = $_POST['descripcion'];
    $nuevo_estado = $_POST['estado'];

    //actualizamos la tarea en la base de datos con un update
    $query_update = "UPDATE tareas SET titulo = ?, descripcion = ?, estado = ? WHERE id = ? AND usuario_id = ?";
    $stmt_update = $conexion->prepare($query_update);
    $stmt_update->bind_param("sssii", $nuevo_titulo, $nueva_descripcion, $nuevo_estado, $tarea_id, $usuario_id);

    if ($stmt_update->execute()) {
        header("Location: ../php/mostrar_tareas.php"); //volvemos a la pagina de las tareas al terminar o nos salta un error
        exit();
    } else {
        echo "<div class='alert alert-danger'>Error al actualizar la tarea.</div>";
    }
    $stmt_update->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Tarea</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            background-color: white;
            padding: 20px;
            width: 50%;
            margin: 0 auto;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        .form-control {
            width: 100%;
            padding: 8px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            margin-top: 10px;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #45a049;
        }
        .back-btn {
            display: inline-block;
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 10px;
        }
        .back-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Editar Tarea</h2>
    <!--formulario que obtiene los datos ya puestos gracias a la sesion -->
    <form method="POST">
        <label for="titulo">Título:</label>
        <input type="text" id="titulo" name="titulo" class="form-control" value="<?php echo $tarea['titulo']; ?>" required>
        
        <label for="descripcion">Descripción:</label>
        <textarea id="descripcion" name="descripcion" class="form-control" required><?php echo $tarea['descripcion']; ?></textarea>
        
        <label for="estado">Estado:</label>
        <select id="estado" name="estado" class="form-control" required>
            <option value="Pendiente" <?php echo ($tarea['estado'] == 'Pendiente' ? 'selected' : ''); ?>>Pendiente</option>
            <option value="Completada" <?php echo ($tarea['estado'] == 'Completada' ? 'selected' : ''); ?>>Completada</option>
        </select>
        
        <label for="aceptar_politicas">
            <input type="checkbox" name="aceptar_politicas" required> Acepto las políticas de privacidad
        </label><br><br>
        
        <button type="submit" class="btn">Actualizar Tarea</button>
    </form>
    <a href="../php/mostrar_tareas.php" class="back-btn">Volver a mis tareas</a>
</div>

</body>
</html>

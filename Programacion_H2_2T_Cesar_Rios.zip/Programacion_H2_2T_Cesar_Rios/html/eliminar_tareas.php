<?php
session_start();
require_once '../config/conexion.php';

// Verificamos si el usuario está autenticado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: iniciar_sesion.php");
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$tarea_id = $_GET['id']; // Obtenemos el ID de la tarea desde la URL.

$conexion = new Conexion();
$conexion = $conexion->getConexion();

// Consultamos los datos de la tarea que se va a eliminar.
$query = "SELECT id, titulo, descripcion, estado FROM tareas WHERE id = ? AND usuario_id = ?";
$stmt = $conexion->prepare($query);
$stmt->bind_param("ii", $tarea_id, $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$tarea = $result->fetch_assoc(); 
$stmt->close();

//se procede a eliminar la tarea.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ejecutamos la consulta para con un delete from.
    $query_delete = "DELETE FROM tareas WHERE id = ? AND usuario_id = ?";
    $stmt_delete = $conexion->prepare($query_delete);
    $stmt_delete->bind_param("ii", $tarea_id, $usuario_id);

    if ($stmt_delete->execute()) {
        header("Location: ../php/mostrar_tareas.php"); //redirigimos 
        exit();
    } else {
        echo "<div class='alert alert-danger'>Error al eliminar la tarea.</div>";
    }
    $stmt_delete->close();
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Tarea</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            background-color: white;
            padding: 20px;
            width: 50%;
            margin: 0 auto;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        .form-control {
            width: 100%;
            padding: 8px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .btn {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 10px 20px;
            margin-top: 10px;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #d32f2f;
        }
        .back-btn {
            display: inline-block;
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 10px;
        }
        .back-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Confirmar Eliminación</h2>
    <p><strong>Título:</strong> <?php echo $tarea['titulo']; ?></p>
    <p><strong>Descripción:</strong> <?php echo $tarea['descripcion']; ?></p>
    <p><strong>Estado:</strong> <?php echo $tarea['estado']; ?></p>
    <p>¿Estás seguro de que deseas eliminar esta tarea?</p>
    <!-- Formulario para confirmar eliminación -->
    <form method="POST">
        <button type="submit" class="btn">Eliminar Tarea</button>
    </form>
    <a href="../php/mostrar_tareas.php" class="back-btn">Cancelar</a>
</div>

</body>
</html>

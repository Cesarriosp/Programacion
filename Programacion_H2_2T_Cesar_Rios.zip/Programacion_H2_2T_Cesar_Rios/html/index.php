
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<title>Página de Inicio</title>
<style>
    body {
        background-color: #222;
        color: white;
        font-family: Arial, sans-serif;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }
    .container {
        background-color: rgba(255, 255, 255, 0.1);
        padding: 20px;
        border-radius: 8px;
        max-width: 400px;
        width: 100%;
        text-align: center;
    }
    .btn {
        display: block;
        margin: 10px auto;
        padding: 10px 20px;
        border-radius: 5px;
        text-decoration: none;
        color: white;
        font-size: 1.1rem;
        width: 80%;
    }
    .btn-primary { background-color: blue; }
    .btn-primary:hover { background-color: darkblue; }
    .btn-success { background-color: green; }
    .btn-success:hover { background-color: darkgreen; }
</style>
</head>
<body>
    <!-- formulario de inicio que nos dirige a los htmls -->
    <div class="container">
        <h2>Bienvenido</h2>
        <p>Accede a tu cuenta o regístrate para gestionar tus tareas.</p>
        <a href="iniciar_sesion.html" class="btn btn-primary">Iniciar Sesión</a>
        <a href="darse_de_alta.html" class="btn btn-success">Registrarse</a>
    </div>
</body>
</html>

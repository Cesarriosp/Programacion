<?php
class Conexion {
    private $conexion;

    public function __construct() {
        // Conectamos a la base de datos.
        $this->conexion = new mysqli("localhost", "root", "curso", "tareas_cesar");
        // Si la conexión falla, mostramos un mensaje de error.
        if ($this->conexion->connect_error) {
            die("Error de conexión: " . $this->conexion->connect_error);
        }
    }

    // Método para obtener la conexión y usarla en otros archivos.
    public function getConexion() {
        return $this->conexion;
    }
}
?>

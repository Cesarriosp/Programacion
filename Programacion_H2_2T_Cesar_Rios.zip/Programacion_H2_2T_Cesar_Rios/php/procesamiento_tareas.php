<?php
session_start(); //iniciamos la sesión para acceder a los datos del usuario

require_once '../config/conexion.php'; // la conexión a la base de datos

//verificamos si el formulario ha sido enviado por POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo = $_POST['titulo']; 
    $descripcion = $_POST['descripcion'];
    $estado = $_POST['estado']; 
    $usuario_id = $_SESSION['usuario_id']; //obtenemos el id desde la sesión
    $conexion = new Conexion(); 
    $conexion = $conexion->getConexion(); 

    //preparamos la consulta para insertar una nueva tarea
    $query = "INSERT INTO tareas (titulo, descripcion, estado, usuario_id) VALUES (?, ?, ?, ?)";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("sssi", $titulo, $descripcion, $estado, $usuario_id); 

    //ejecutamos la consulta y verificamos 
    if ($stmt->execute()) {
        header("Location: mostrar_tareas.php");
    } else {
        echo "<div class='alert alert-danger'>Hubo un error al agregar la tarea.</div>";
    }
    $stmt->close();
}
?>

<?php
require_once '../config/conexion.php';

//verificamos si el formulario fue enviado por POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre_usuario = $_POST['nombre_usuario'];
    $correo = $_POST['correo'];
    $contraseña = password_hash($_POST['contraseña'], PASSWORD_BCRYPT); //Encriptamos la contraseña 
    $conexion = new Conexion();
    $conexion = $conexion->getConexion();

    //Definimos una clase para manejar al socio
    class Socio {
        private $conexion;
        //constructor para la conexion
        public function __construct($conexion) {
            $this->conexion = $conexion;
        }
        public function agregarSocio($nombre_usuario, $correo, $contraseña) {
            //consulta para insertar un nuevo socio
            $query = "INSERT INTO usuarios (nombre_usuario, correo, contraseña) VALUES (?, ?, ?)";
            $stmt = $this->conexion->prepare($query);
            $stmt->bind_param("sss", $nombre_usuario, $correo, $contraseña);
            //ejecutamos y verificamos si se ha insertado correctamente
            if ($stmt->execute()) {
                echo '<h1>Socio agregado con éxito</h1>'; 
            } else {
                echo "<h2>Error al agregar socio</h2>"; 
            }
            $stmt->close(); //Cerramos la consulta
        }
    }
    $controller = new Socio($conexion);
    //Llamamos para agregar el socio
    $controller->agregarSocio($nombre_usuario, $correo, $contraseña);
}
?>
<a class="btn" href="../html/index.php">Volver al inicio</a>

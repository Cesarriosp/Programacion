<?php
session_start();
require_once '../config/conexion.php';

//verificamos si el formulario fue enviado por POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = $_POST['correo'];
    $contraseña = $_POST['contraseña']; 

    $conexion = new Conexion();
    $conexion = $conexion->getConexion();
    //consulta para obtener los datos del usuario según el correo
    $query = "SELECT id, nombre_usuario, correo, contraseña FROM usuarios WHERE correo = ?";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("s", $correo);
    $stmt->execute();
    $result = $stmt->get_result();
    //verificamos si el correo existe y si la contraseña coincide
    if ($row = $result->fetch_assoc()) {
        if (password_verify($contraseña, $row['contraseña'])) { //verificamos la contraseña encriptada
            //si todo es correcto, creamos las variables de sesión
            $_SESSION['usuario_id'] = $row['id'];
            $_SESSION['nombre_usuario'] = $row['nombre_usuario'];
            $_SESSION['correo'] = $row['correo'];
            header('Location: mostrar_tareas.php'); 
            exit();
        } else {
            echo "<div class='alert alert-danger'>Contraseña incorrecta.</div>";
        }
    } else {
        //si no existe el correo en la base de datos
        echo "<div class='alert alert-danger'>Correo no registrado.</div>";
    }
    $stmt->close(); //cerramos
}
?>

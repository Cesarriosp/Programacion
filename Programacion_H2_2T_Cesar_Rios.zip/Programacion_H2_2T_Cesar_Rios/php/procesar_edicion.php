<?php
session_start();
require_once '../config/conexion.php';

// verificamos que el usuario está autenticado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: iniciar_sesion.php");
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$tarea_id = $_GET['id']; //obtenemos el ID de la tarea de la URL

$conexion = new Conexion();
$conexion = $conexion->getConexion();

//obtenemos los datos de la tarea que el usuario va a editar
$query = "SELECT id, titulo, descripcion, estado FROM tareas WHERE id = ? AND usuario_id = ?";
$stmt = $conexion->prepare($query);
$stmt->bind_param("ii", $tarea_id, $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$tarea = $result->fetch_assoc(); 
$stmt->close();

header("Location: editar_tareas_formulario.php?id=" . $tarea['id']);
exit();
?>

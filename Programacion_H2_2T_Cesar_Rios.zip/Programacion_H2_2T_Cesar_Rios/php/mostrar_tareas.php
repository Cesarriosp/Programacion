<?php
session_start();
require_once '../config/conexion.php';

// Verificamos que el usuario está autenticado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: iniciar_sesion.php");
    exit();
}

// nos conectamos a su base de datos
$usuario_id = $_SESSION['usuario_id'];
$conexion = new Conexion();
$conexion = $conexion->getConexion();

//obtenemos sus tareas del usuario
$query = "SELECT id, titulo, descripcion, estado, fecha_creacion FROM tareas WHERE usuario_id = ?";
$stmt = $conexion->prepare($query);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();

// mostramos las tareas con un while
echo "<div class='container'>";
echo "<h2>Tareas del Usuario</h2>";
echo "<a href='../html/crear_tareas.html' class='btn'>Agregar Nueva Tarea</a>";

if ($result->num_rows > 0) {
    echo "<ul>";
    while ($row = $result->fetch_assoc()) {
        echo "<li>";
        echo "<strong>Título:</strong> " . $row['titulo'] . "<br>";
        echo "<strong>Descripción:</strong> " . $row['descripcion'] . "<br>";
        echo "<strong>Estado:</strong> " . $row['estado'] . "<br>";
        echo "<strong>Fecha de Creación:</strong> " . $row['fecha_creacion'] . "<br>";
        // añadimos las ppciones de editar y eliminar
        echo "<a href='../html/editar_tareas.php?id=" . $row['id'] . "' class='btn btn-primary'>Editar</a> ";
        echo "<a href='../html/eliminar_tareas.php?id=" . $row['id'] . "' class='btn btn-danger'>Eliminar</a>";
        echo "</li>";
    }
    echo "</ul>";
} else {
    echo "<p>No tienes tareas.</p>";
}

echo "<a href='../html/index.php' class='btn btn-back'>Volver al Inicio</a>";
echo "</div>";

$stmt->close();
?>

<!--Estilos simples-->
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 20px;
    }
    .container {
        background-color: white;
        border-radius: 5px;
        padding: 20px;
        width: 60%;
        margin: 0 auto;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    }
    h2 {
        text-align: center;
    }
    ul {
        list-style-type: none;
        padding-left: 0;
    }
    li {
        margin-bottom: 20px;
    }
    a {
        text-decoration: none;
        padding: 8px 15px;
        border-radius: 5px;
        font-size: 14px;
        margin-right: 10px;
    }
    .btn {
        background-color: #4CAF50;
        color: white;
        border: none;
        transition: background-color 0.3s;
    }
    .btn:hover {
        background-color: #45a049;
    }
    .btn-primary {
        background-color: #008CBA;
    }
    .btn-primary:hover {
        background-color: #007bb5;
    }
    .btn-danger {
        background-color: #f44336;
    }
    .btn-danger:hover {
        background-color: #e53935;
    }
    .btn-back {
        background-color: #777;
        color: white;
        display: block;
        text-align: center;
        margin-top: 20px;
        text-decoration: none;
        padding: 10px 20px;
        border-radius: 5px;
    }
    .btn-back:hover {
        background-color: #555;
    }
</style>

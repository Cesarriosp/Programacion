<?php
session_start();
require_once '../config/conexion.php';

//verificamos
if (!isset($_SESSION['usuario_id'])) {
    header("Location: procesamiento_inicio_sesion.php"); 
    exit();
}

// si se ha recibido el ID de la tarea para eliminar
if (isset($_GET['id'])) {
    $tarea_id = $_GET['id']; 
    $usuario_id = $_SESSION['usuario_id']; 
    $conexion = new Conexion();
    $conexion = $conexion->getConexion();
    // consulta para eliminar la tarea
    $query = "DELETE FROM tareas WHERE id = ? AND usuario_id = ?";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("ii", $tarea_id, $usuario_id);

    if ($stmt->execute()) {
        header("Location: ../php/mostrar_tareas.php");
        exit();
    } else {
        echo "<div class='alert alert-danger'>No se pudo eliminar la tarea. Intenta nuevamente.</div>";
    }
    $stmt->close();
} else {
    //si no se recibe el ID de la tarea, mostrar un mensaje de error
    echo "<div class='alert alert-danger'>ID de tarea no proporcionado.</div>";
}
?>

<a class="btn" href="../php/mostrar_tareas.php">Volver a Mis Tareas</a>

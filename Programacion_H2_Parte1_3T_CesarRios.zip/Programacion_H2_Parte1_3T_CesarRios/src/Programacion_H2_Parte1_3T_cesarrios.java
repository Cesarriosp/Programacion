import java.sql.*;
import java.util.Scanner;

public class Programacion_H2_Parte1_3T_cesarrios {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/cine"; 
        String usuario = "root";
        String contraseña = "curso";

        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n----- MENÚ -----");
            System.out.println("1 - Ver películas");
            System.out.println("2 - Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    mostrarPeliculas(url, usuario, contraseña);
                    break;
                case 2:
                    System.out.println("Saliendo del programa del hito...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }

        } while (opcion != 2);

        scanner.close();
    }

    public static void mostrarPeliculas(String url, String usuario, String contraseña) {
        String sql = "SELECT p.id_pelicula, p.titulo, p.director, p.duracion, p.clasificacion, g.nombre_genero " +
                     "FROM Peliculas p JOIN Generos g ON p.genero_id = g.id_genero";

        try (
            Connection conexion = DriverManager.getConnection(url, usuario, contraseña);
            Statement stmt = conexion.createStatement();
            ResultSet rs = stmt.executeQuery(sql)
        ) {
            System.out.println("\n----- LISTADO DE PELÍCULAS -----");

            while (rs.next()) {
                System.out.println("ID: " + rs.getString("id_pelicula"));
                System.out.println("Título: " + rs.getString("titulo"));
                System.out.println("Director: " + rs.getString("director"));
                System.out.println("Duración: " + rs.getInt("duracion") + " minutos");
                System.out.println("Clasificación: " + rs.getString("clasificacion"));
                System.out.println("Género: " + rs.getString("nombre_genero"));
                System.out.println("----------------------------------------");
            }

        } catch (SQLException e) {
            System.out.println("Error al acceder a la base de datos: " + e.getMessage());
        }
    }
}


